# FairShift — recovered deployment launcher

This is NOT the original source-code project. It is a recovered HTML launcher referencing the compiled CSS and JavaScript currently hosted at https://fairshift-side-by-side.vercel.app.

It requires an internet connection and access to those hosted assets. It is not a complete offline backup, React/TypeScript source tree, or suitable substitute for source-code submission.

To recover the original source, locate the original fairshift-side-by-side.zip or local project directory.
